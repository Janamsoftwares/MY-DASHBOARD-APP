# Dr.Net Admin Portal - Production Ready

A secure, production-ready admin portal for Dr.Net Technology Labs with enterprise-grade authentication and session management.

## 🚀 Features

### Security Features
- **JWT Authentication** with secure token management
- **Password Hashing** using bcrypt with salt rounds
- **Rate Limiting** to prevent brute force attacks
- **Session Management** with automatic token expiration
- **CORS Protection** and security headers
- **Input Validation** and sanitization
- **Audit Logging** for all authentication events

### Admin Features
- User registration and management
- Real-time dashboard with analytics
- Invoice generation with PDF export
- SMS template generation
- Renewal management
- Website booking management
- Data export capabilities

## 🛠 Setup Instructions

### 1. Backend Setup

```bash
# Navigate to server directory
cd server

# Install dependencies
npm install

# Generate password hash
npm run generate-hash

# Copy the generated hash to your .env file
```

### 2. Environment Configuration

Create a `.env` file in the root directory:

```env
# Database Configuration
DATABASE_URL=your_database_connection_string_here

# JWT Configuration
JWT_SECRET=your_super_secure_jwt_secret_key_here_make_it_long_and_random
JWT_EXPIRES_IN=24h

# Admin Credentials
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=your_generated_hash_here

# Server Configuration
PORT=5000
NODE_ENV=production

# CORS Configuration
FRONTEND_URL=http://localhost:5173

# Rate Limiting
MAX_LOGIN_ATTEMPTS=5
LOCKOUT_TIME=15

# Session Configuration
SESSION_SECRET=your_session_secret_here
```

### 3. Frontend Setup

```bash
# Install frontend dependencies
npm install

# Create frontend environment file
echo "VITE_API_URL=http://localhost:5000/api" > .env.local
```

### 4. Running the Application

#### Development Mode

```bash
# Terminal 1: Start backend server
cd server
npm run dev

# Terminal 2: Start frontend
npm run dev
```

#### Production Mode

```bash
# Build frontend
npm run build

# Start backend server
cd server
npm start

# Serve frontend (using a static server like nginx or serve)
npx serve dist
```

## 🔐 Security Implementation

### Password Security
- Passwords are hashed using bcrypt with 12 salt rounds
- No plaintext passwords are stored anywhere
- Password change functionality with current password verification

### Token Management
- JWT tokens with configurable expiration
- Automatic token refresh on valid requests
- Secure token storage in localStorage with expiration checks
- Token blacklisting on logout (implement Redis for production)

### Rate Limiting
- Maximum 5 login attempts per IP address
- 15-minute lockout period after failed attempts
- Progressive delays for repeated failures

### API Security
- CORS protection with specific origin allowlist
- Helmet.js for security headers
- Input validation and sanitization
- Error handling without information leakage

## 📊 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/verify` - Token verification
- `POST /api/auth/logout` - User logout
- `POST /api/auth/change-password` - Password change

### Admin
- `GET /api/admin/dashboard` - Dashboard data
- `GET /api/health` - Health check

## 🚀 Deployment Guide

### Environment Variables for Production

```env
NODE_ENV=production
JWT_SECRET=your_production_jwt_secret_minimum_32_characters
ADMIN_PASSWORD_HASH=your_bcrypt_hash
DATABASE_URL=your_production_database_url
FRONTEND_URL=https://your-domain.com
```

### Security Checklist

- [ ] Change default admin credentials
- [ ] Use strong JWT secret (minimum 32 characters)
- [ ] Enable HTTPS in production
- [ ] Configure proper CORS origins
- [ ] Set up database with proper access controls
- [ ] Implement Redis for session management
- [ ] Set up monitoring and logging
- [ ] Configure firewall rules
- [ ] Regular security updates

### Recommended Production Setup

1. **Database**: PostgreSQL or MongoDB with proper indexing
2. **Cache**: Redis for session management and rate limiting
3. **Reverse Proxy**: Nginx with SSL termination
4. **Process Manager**: PM2 for Node.js process management
5. **Monitoring**: Application monitoring with alerts
6. **Backup**: Automated database backups
7. **SSL**: Let's Encrypt or commercial SSL certificate

## 🔧 Customization

### Adding New Admin Users
Modify the authentication logic in `server/index.js` to support multiple users with a database.

### Database Integration
Replace the in-memory storage with your preferred database:
- PostgreSQL with Prisma
- MongoDB with Mongoose
- MySQL with Sequelize

### Additional Security Features
- Two-factor authentication (2FA)
- IP whitelisting
- Advanced audit logging
- Session management with Redis

## 📝 License

MIT License - see LICENSE file for details.

## 🆘 Support

For technical support or questions:
- Email: dr.netinnovations@gmail.com
- Phone: 0701782354

---

**Dr.Net Technology Labs** - Professional Internet Service Provider Solutions