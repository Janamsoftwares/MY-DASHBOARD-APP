import React from 'react';
import { Booking } from '../types';
import { Globe, RefreshCw, Mail, Phone, MapPin } from 'lucide-react';
import { formatDate } from '../utils/formatters';
import Swal from 'sweetalert2';

interface WebsiteBookingsProps {
  bookings: Booking[];
  onRefreshBookings: () => void;
}

const WebsiteBookings: React.FC<WebsiteBookingsProps> = ({ bookings, onRefreshBookings }) => {
  const handleRefresh = () => {
    onRefreshBookings();
    Swal.fire('Refreshed', 'Bookings have been refreshed', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Globe className="w-8 h-8 text-indigo-600" />
          <h3 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Website Bookings
          </h3>
        </div>
        <button
          onClick={handleRefresh}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
        >
          <div className="flex items-center">
            <RefreshCw className="w-5 h-5 mr-2" />
            Refresh Bookings
          </div>
        </button>
      </div>

      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <div className="space-y-6">
          {bookings.length === 0 ? (
            <div className="text-center py-12">
              <Globe className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No bookings found</p>
              <p className="text-gray-400 text-sm">Customer inquiries will appear here</p>
            </div>
          ) : (
            bookings.map((booking) => (
              <div key={booking.id} className="bg-gradient-to-r from-white to-blue-50 p-6 rounded-xl hover:shadow-lg transition-all duration-300 border border-blue-100">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h5 className="font-semibold text-lg text-gray-800 mb-3">{booking.name}</h5>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-center text-gray-600">
                        <Mail className="w-4 h-4 mr-2 text-blue-500" />
                        <span>{booking.email}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-600">
                        <Phone className="w-4 h-4 mr-2 text-green-500" />
                        <span>{booking.phone}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-600">
                        <MapPin className="w-4 h-4 mr-2 text-red-500" />
                        <span>{booking.location}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-600">
                        <Globe className="w-4 h-4 mr-2 text-purple-500" />
                        <span>{booking.package}</span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-700">
                        <strong>Message:</strong> {booking.message}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right ml-6">
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                      {formatDate(booking.date)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default WebsiteBookings;