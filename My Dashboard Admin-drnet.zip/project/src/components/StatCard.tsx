import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle: string;
  icon: LucideIcon;
  color: string;
  onClick?: () => void;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  color, 
  onClick 
}) => {
  return (
    <div 
      onClick={onClick}
      className={`card-enhanced p-8 rounded-2xl transition-all duration-300 border-l-4 ${
        onClick ? 'cursor-pointer hover:scale-105 hover:shadow-xl' : ''
      }`}
      style={{ borderLeftColor: color }}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="font-semibold text-lg mb-2" style={{ color }}>
            {title}
          </p>
          <p className="text-4xl font-bold text-gray-800 mb-1">{value}</p>
          <p className="text-sm text-gray-500">{subtitle}</p>
        </div>
        <div className="text-5xl opacity-80">
          <Icon size={48} style={{ color }} />
        </div>
      </div>
    </div>
  );
};

export default StatCard;