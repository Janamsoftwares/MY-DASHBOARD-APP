import React, { useState } from 'react';
import { User } from '../types';
import { RefreshCw, Calendar, Users as UsersIcon, DollarSign } from 'lucide-react';
import { formatDate, formatCurrency } from '../utils/formatters';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';

interface RenewalsProps {
  users: User[];
  onUserUpdated: (updatedUser: User) => void;
}

const Renewals: React.FC<RenewalsProps> = ({ users, onUserUpdated }) => {
  const [selectedUserId, setSelectedUserId] = useState('');
  const [renewalAmount, setRenewalAmount] = useState('');

  // Filter out deleted users for all calculations
  const activeUsers = users.filter(u => !u.isDeleted);
  const now = new Date();
  const fiveDaysFromNow = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);
  
  const expiringSoon = activeUsers.filter(user => 
    new Date(user.expiryDate) > now && 
    new Date(user.expiryDate) <= fiveDaysFromNow
  );
  
  const dormantUsers = activeUsers.filter(user => 
    new Date(user.expiryDate) <= now
  );

  const currentMonth = dayjs().format('YYYY-MM');
  const monthlyRenewals = activeUsers.filter(user => 
    user.paidSubscription && 
    user.paymentDate && 
    user.paymentDate.startsWith(currentMonth)
  );

  const renewalsRevenue = monthlyRenewals.reduce((sum, user) => sum + user.subscriptionAmount, 0);

  const handleQuickRenewal = () => {
    if (!selectedUserId || !renewalAmount) {
      Swal.fire('Error', 'Please select a user and enter renewal amount', 'error');
      return;
    }

    const user = users.find(u => u._id === selectedUserId);
    if (!user) {
      Swal.fire('Error', 'User not found', 'error');
      return;
    }

    const updatedUser: User = {
      ...user,
      subscriptionAmount: parseInt(renewalAmount),
      paidSubscription: true,
      paymentDate: dayjs().format('YYYY-MM-DD'),
      expiryDate: dayjs().add(30, 'days').format('YYYY-MM-DD')
    };

    onUserUpdated(updatedUser);
    setRenewalAmount('');
    setSelectedUserId('');
    
    Swal.fire('Success', `${user.name} renewed successfully!`, 'success');
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center space-x-3 mb-6">
        <RefreshCw className="w-8 h-8 text-indigo-600" />
        <h3 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          Renewal Management
        </h3>
      </div>

      {/* Quick Renewal Form */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
          <RefreshCw className="w-6 h-6 mr-2 text-indigo-600" />
          Quick User Renewal
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Select User</label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            >
              <option value="">Choose a user...</option>
              {activeUsers.map(user => (
                <option key={user._id} value={user._id}>
                  {user.name} - {user.location}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Renewal Amount (Ksh)</label>
            <input
              type="number"
              value={renewalAmount}
              onChange={(e) => setRenewalAmount(e.target.value)}
              placeholder="Enter amount"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={handleQuickRenewal}
              className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-4 rounded-xl hover:from-green-600 hover:to-green-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <div className="flex items-center justify-center">
                <RefreshCw className="w-5 h-5 mr-2" />
                Renew Now
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Status Sections */}
      {(expiringSoon.length > 0 || dormantUsers.length > 0) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Expiring Soon Users */}
          {expiringSoon.length > 0 && (
            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border-l-4 border-yellow-400 p-8 rounded-2xl shadow-lg">
              <h4 className="text-lg font-semibold text-yellow-700 mb-6 flex items-center">
                <Calendar className="w-6 h-6 mr-2" />
                Users Expiring Soon (Next 5 Days)
              </h4>
              <div className="space-y-4">
                {expiringSoon.map(user => (
                  <div key={user._id} className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold">{user.name}</p>
                        <p className="text-sm text-gray-600">Expires: {formatDate(user.expiryDate)}</p>
                      </div>
                      <span className="text-lg font-bold text-yellow-700">
                        {formatCurrency(user.subscriptionAmount)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Dormant Users */}
          {dormantUsers.length > 0 && (
            <div className="bg-gradient-to-r from-red-50 to-pink-50 border-l-4 border-red-400 p-8 rounded-2xl shadow-lg">
              <h4 className="text-lg font-semibold text-red-700 mb-6 flex items-center">
                <UsersIcon className="w-6 h-6 mr-2" />
                Dormant Users
              </h4>
              <div className="space-y-4">
                {dormantUsers.map(user => (
                  <div key={user._id} className="p-4 bg-red-50 rounded-lg border border-red-200">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold">{user.name}</p>
                        <p className="text-sm text-gray-600">Expired: {formatDate(user.expiryDate)}</p>
                      </div>
                      <span className="text-lg font-bold text-red-700">
                        {formatCurrency(user.subscriptionAmount)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Monthly Renewals Summary */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
          <DollarSign className="w-6 h-6 mr-2 text-green-600" />
          {dayjs().format('MMMM')} Renewals Summary
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="text-center p-6 bg-gradient-to-r from-green-50 to-green-100 rounded-xl border border-green-200">
            <p className="text-3xl font-bold text-green-600">{monthlyRenewals.length}</p>
            <p className="text-sm text-gray-600 font-medium">Renewals This Month</p>
          </div>
          
          <div className="text-center p-6 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
            <p className="text-3xl font-bold text-blue-600">{formatCurrency(renewalsRevenue)}</p>
            <p className="text-sm text-gray-600 font-medium">Total Revenue</p>
          </div>
          
          <div className="text-center p-6 bg-gradient-to-r from-yellow-50 to-yellow-100 rounded-xl border border-yellow-200">
            <p className="text-3xl font-bold text-yellow-600">
              {monthlyRenewals.length > 0 ? formatCurrency(Math.round(renewalsRevenue / monthlyRenewals.length)) : formatCurrency(0)}
            </p>
            <p className="text-sm text-gray-600 font-medium">Average Per Renewal</p>
          </div>
        </div>

        {monthlyRenewals.length > 0 ? (
          <>
            <hr className="my-6 border-gray-200" />
            <div>
              <h5 className="font-semibold text-gray-800 mb-4">Recent Renewals</h5>
              <div className="space-y-3">
                {monthlyRenewals.slice(0, 5).map(user => (
                  <div key={user._id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium">{user.name}</span>
                    <span className="text-green-600 font-semibold">
                      {formatCurrency(user.subscriptionAmount)}
                    </span>
                  </div>
                ))}
                {monthlyRenewals.length > 5 && (
                  <p className="text-sm text-gray-500 text-center">
                    And {monthlyRenewals.length - 5} more renewals...
                  </p>
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-8">
            <div className="text-4xl mb-4">📊</div>
            <p className="text-gray-500">No renewals this month yet</p>
            <p className="text-gray-400 text-sm">Renewals will appear here once users pay</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Renewals;