import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface NotificationBoxProps {
  show: boolean;
  onViewExpired: () => void;
}

const NotificationBox: React.FC<NotificationBoxProps> = ({ show, onViewExpired }) => {
  if (!show) return null;

  return (
    <div className="mb-8 bg-gradient-to-r from-yellow-50 to-orange-50 border-l-4 border-yellow-400 p-6 rounded-xl shadow-lg animate-pulse">
      <div className="flex items-center">
        <AlertTriangle className="w-8 h-8 text-yellow-600 mr-4" />
        <div>
          <p className="font-semibold text-yellow-800">Attention Required</p>
          <p className="text-yellow-700">
            Some users are expiring soon.{' '}
            <button 
              onClick={onViewExpired}
              className="underline hover:text-yellow-900 font-medium transition-colors"
            >
              View Now
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotificationBox;