import React from 'react';
import { User } from '../types';
import { X } from 'lucide-react';
import { formatDate } from '../utils/formatters';

interface DetailedViewProps {
  isVisible: boolean;
  title: string;
  users: User[];
  onClose: () => void;
}

const DetailedView: React.FC<DetailedViewProps> = ({ isVisible, title, users, onClose }) => {
  if (!isVisible) return null;

  return (
    <div className="mt-10 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg p-8">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          {title}
        </h3>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 text-3xl font-bold transition-colors duration-200"
        >
          <X size={24} />
        </button>
      </div>
      
      <div className="overflow-x-auto">
        {users.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No users found in this category.</p>
        ) : (
          <table className="min-w-full table-auto">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-4 py-3 text-left font-semibold">Name</th>
                <th className="px-4 py-3 text-left font-semibold">Phone</th>
                <th className="px-4 py-3 text-left font-semibold">Location</th>
                <th className="px-4 py-3 text-left font-semibold">Amount</th>
                <th className="px-4 py-3 text-left font-semibold">Expiry</th>
                <th className="px-4 py-3 text-left font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user._id} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium">{user.name}</td>
                  <td className="px-4 py-3">{user.phone}</td>
                  <td className="px-4 py-3">{user.location}</td>
                  <td className="px-4 py-3">KSH {user.subscriptionAmount.toLocaleString()}</td>
                  <td className="px-4 py-3">{formatDate(user.expiryDate)}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      user.paidSubscription 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {user.paidSubscription ? 'Paid' : 'Unpaid'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default DetailedView;