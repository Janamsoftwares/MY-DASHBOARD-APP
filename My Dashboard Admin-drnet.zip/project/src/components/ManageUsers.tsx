import React from 'react';
import { User } from '../types';
import { Users, Download, Trash2 } from 'lucide-react';
import { formatDate, exportToCSV } from '../utils/formatters';
import Swal from 'sweetalert2';
import dayjs from 'dayjs';

interface ManageUsersProps {
  users: User[];
  onDeleteUser: (userId: string) => void;
}

const ManageUsers: React.FC<ManageUsersProps> = ({ users, onDeleteUser }) => {
  const activeUsers = users.filter(u => !u.isDeleted);

  const handleDeleteUser = (userId: string, userName: string) => {
    Swal.fire({
      title: 'Are you sure?',
      text: `You won't be able to revert deleting ${userName}!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        onDeleteUser(userId);
        Swal.fire('Deleted!', 'User has been deleted.', 'success');
      }
    });
  };

  const handleExportCSV = () => {
    const filename = `dr-net-users-${dayjs().format('YYYY-MM-DD')}.csv`;
    exportToCSV(activeUsers, filename);
    Swal.fire('Success', 'Users exported to CSV successfully!', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Users className="w-8 h-8 text-indigo-600" />
          <h3 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Manage Users
          </h3>
        </div>
        <button
          onClick={handleExportCSV}
          className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 rounded-xl hover:from-green-600 hover:to-green-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
        >
          <div className="flex items-center">
            <Download className="w-5 h-5 mr-2" />
            Export to CSV
          </div>
        </button>
      </div>

      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <div className="space-y-4">
          {activeUsers.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No users found</p>
            </div>
          ) : (
            activeUsers.map((user) => (
              <div key={user._id} className="bg-gradient-to-r from-white to-gray-50 p-6 rounded-xl hover:shadow-lg transition-all duration-300 border border-gray-100">
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <h5 className="font-semibold text-lg text-gray-800">{user.name}</h5>
                    <p className="text-gray-600">{user.phone} • {user.location}</p>
                    <p className="text-sm text-gray-500 mt-1">{user.package}</p>
                    <div className="flex items-center mt-3 space-x-4">
                      <span className={`px-3 py-1 text-xs rounded-full font-medium ${
                        user.paidSubscription 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {user.paidSubscription ? 'Paid' : 'Unpaid'}
                      </span>
                      <span className="text-sm text-gray-600">
                        Expires: {formatDate(user.expiryDate)}
                      </span>
                    </div>
                  </div>
                  <div className="text-right flex flex-col items-end space-y-2">
                    <p className="font-bold text-lg text-gray-800">
                      KSH {user.subscriptionAmount.toLocaleString()}
                    </p>
                    <button
                      onClick={() => handleDeleteUser(user._id, user.name)}
                      className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-all duration-200 text-sm font-medium flex items-center"
                    >
                      <Trash2 className="w-4 h-4 mr-1" />
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ManageUsers;