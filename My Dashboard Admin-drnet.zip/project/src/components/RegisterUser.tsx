import React, { useState } from 'react';
import dayjs from 'dayjs';
import { User } from '../types';
import { UserPlus } from 'lucide-react';
import Swal from 'sweetalert2';

interface RegisterUserProps {
  onUserRegistered: (user: User) => void;
}

const RegisterUser: React.FC<RegisterUserProps> = ({ onUserRegistered }) => {
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    phone: '',
    subscriptionAmount: '',
    routerCost: '',
    paymentDate: '',
    paidSubscription: false,
    package: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newUser: User = {
      _id: Date.now().toString(),
      name: formData.name,
      phone: formData.phone,
      location: formData.location,
      subscriptionAmount: parseInt(formData.subscriptionAmount),
      routerCost: parseInt(formData.routerCost),
      paymentDate: formData.paymentDate,
      paidSubscription: formData.paidSubscription,
      package: formData.package,
      expiryDate: dayjs(formData.paymentDate).add(30, 'days').format('YYYY-MM-DD'),
      isDeleted: false
    };

    onUserRegistered(newUser);
    
    Swal.fire({
      title: 'Success!',
      text: 'User registered successfully!',
      icon: 'success',
      confirmButtonText: 'OK'
    });

    // Reset form
    setFormData({
      name: '',
      location: '',
      phone: '',
      subscriptionAmount: '',
      routerCost: '',
      paymentDate: '',
      paidSubscription: false,
      package: ''
    });
  };

  const packages = [
    'Bronze Plan - Up to 5 Mbps (Ksh 1,500/Month)',
    'Silver Plan - Up to 10 Mbps (Ksh 2,000/Month)',
    'Gold Plan - Up to 15 Mbps (Ksh 2,500/Month)',
    'Platinum Plan - Up to 20 Mbps (Ksh 3,000/Month)',
    'Super Plan - Up to 35 Mbps (Ksh 4,500/Month)',
    'Dedicated Link - Up to 200 Mbps (Contact for Quote)'
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3 mb-6">
        <UserPlus className="w-8 h-8 text-indigo-600" />
        <h3 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          Register New User
        </h3>
      </div>

      <form onSubmit={handleSubmit} className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              placeholder="Enter full name"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Location</label>
            <input
              type="text"
              name="location"
              value={formData.location}
              onChange={handleInputChange}
              placeholder="Enter location"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
            <input
              type="text"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
              placeholder="+254 xxx xxx xxx"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Subscription Amount</label>
            <input
              type="number"
              name="subscriptionAmount"
              value={formData.subscriptionAmount}
              onChange={handleInputChange}
              placeholder="Enter amount"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Router Cost</label>
            <input
              type="number"
              name="routerCost"
              value={formData.routerCost}
              onChange={handleInputChange}
              placeholder="0 if none"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Payment Date</label>
            <input
              type="date"
              name="paymentDate"
              value={formData.paymentDate}
              onChange={handleInputChange}
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
        </div>

        <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
          <input
            type="checkbox"
            id="paidSubscription"
            name="paidSubscription"
            checked={formData.paidSubscription}
            onChange={handleInputChange}
            className="w-5 h-5 text-indigo-600 border-2 border-gray-300 rounded focus:ring-indigo-500"
          />
          <label htmlFor="paidSubscription" className="text-gray-700 font-medium">
            Has the user paid the subscription?
          </label>
        </div>

        <div>
          <label htmlFor="package" className="block text-sm font-semibold text-gray-700 mb-2">
            Select Internet Package
          </label>
          <select
            name="package"
            value={formData.package}
            onChange={handleInputChange}
            required
            className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
          >
            <option value="" disabled>Choose a Package</option>
            {packages.map((pkg, index) => (
              <option key={index} value={pkg}>{pkg}</option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-lg font-semibold py-4 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
        >
          <div className="flex items-center justify-center">
            <UserPlus className="w-5 h-5 mr-2" />
            Register User
          </div>
        </button>
      </form>
    </div>
  );
};

export default RegisterUser;