import React, { useState } from 'react';
import { User, Invoice } from '../types';
import { FileText, Download, MessageSquare, Copy } from 'lucide-react';
import { generateInvoicePDF } from '../utils/pdfGenerator';
import { generateInvoiceMessage, generateReminderMessage, generatePaymentConfirmation } from '../utils/smsTemplates';
import { generateInvoiceNumber, formatDate } from '../utils/formatters';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';

interface InvoiceGeneratorProps {
  users: User[];
}

const InvoiceGenerator: React.FC<InvoiceGeneratorProps> = ({ users }) => {
  const [selectedUserId, setSelectedUserId] = useState('');
  const [currentSMS, setCurrentSMS] = useState('');
  const [showInvoicePreview, setShowInvoicePreview] = useState(false);
  const [showSMSPreview, setShowSMSPreview] = useState(false);
  const [currentInvoice, setCurrentInvoice] = useState<Invoice | null>(null);

  const activeUsers = users.filter(u => !u.isDeleted);

  const handleGenerateInvoice = () => {
    if (!selectedUserId) {
      Swal.fire('Error', 'Please select a user first', 'error');
      return;
    }

    const user = users.find(u => u._id === selectedUserId);
    if (!user) {
      Swal.fire('Error', 'User not found', 'error');
      return;
    }

    const invoice: Invoice = {
      id: 'INV-' + Date.now(),
      userId: user._id,
      userName: user.name,
      userPhone: user.phone,
      userLocation: user.location,
      amount: user.subscriptionAmount,
      invoiceNumber: generateInvoiceNumber(),
      issueDate: dayjs().format('YYYY-MM-DD'),
      dueDate: dayjs().add(7, 'days').format('YYYY-MM-DD'),
      status: 'pending'
    };

    setCurrentInvoice(invoice);
    generateInvoicePDF(invoice);
    setShowInvoicePreview(true);
    
    Swal.fire('Success', 'Invoice PDF generated successfully!', 'success');
  };

  const handleGenerateSMS = (type: 'invoice' | 'reminder' | 'confirmation') => {
    if (!selectedUserId) {
      Swal.fire('Error', 'Please select a user first', 'error');
      return;
    }

    const user = users.find(u => u._id === selectedUserId);
    if (!user) {
      Swal.fire('Error', 'User not found', 'error');
      return;
    }

    const invoice: Invoice = {
      id: 'INV-' + Date.now(),
      userId: user._id,
      userName: user.name,
      userPhone: user.phone,
      userLocation: user.location,
      amount: user.subscriptionAmount,
      invoiceNumber: generateInvoiceNumber(),
      issueDate: dayjs().format('YYYY-MM-DD'),
      dueDate: dayjs().add(7, 'days').format('YYYY-MM-DD'),
      status: 'pending'
    };

    let smsContent = '';
    switch (type) {
      case 'invoice':
        smsContent = generateInvoiceMessage(invoice);
        break;
      case 'reminder':
        smsContent = generateReminderMessage(invoice);
        break;
      case 'confirmation':
        smsContent = generatePaymentConfirmation(invoice);
        break;
    }

    setCurrentSMS(smsContent);
    setShowSMSPreview(true);
  };

  const handleCopySMS = async () => {
    try {
      await navigator.clipboard.writeText(currentSMS);
      Swal.fire('Copied!', 'SMS content copied to clipboard', 'success');
    } catch (err) {
      Swal.fire('Error', 'Failed to copy to clipboard', 'error');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center space-x-3 mb-6">
        <FileText className="w-8 h-8 text-indigo-600" />
        <h3 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          Invoice Generator
        </h3>
      </div>

      {/* Invoice Generation */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6">Generate Invoice</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Select User</label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            >
              <option value="">Choose a user...</option>
              {activeUsers.map(user => (
                <option key={user._id} value={user._id}>
                  {user.name} - {user.location}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={handleGenerateInvoice}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <div className="flex items-center justify-center">
                <Download className="w-5 h-5 mr-2" />
                Generate Invoice PDF
              </div>
            </button>
          </div>
        </div>

        {/* Invoice Preview */}
        {showInvoicePreview && currentInvoice && (
          <div className="mt-6 p-6 bg-gray-50 rounded-xl">
            <h5 className="font-semibold text-gray-800 mb-4">Invoice Preview</h5>
            <div className="border rounded-lg p-4 bg-white">
              <div className="flex justify-between mb-4">
                <div>
                  <h6 className="font-bold text-lg text-pink-600">DR.NET TECHNOLOGY LABS</h6>
                  <p className="text-sm text-gray-600">Internet Service Provider</p>
                </div>
                <div className="text-right">
                  <h6 className="font-bold">INVOICE</h6>
                  <p className="text-sm">#{currentInvoice.invoiceNumber}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="font-semibold">Bill To:</p>
                  <p>{currentInvoice.userName}</p>
                  <p>{currentInvoice.userPhone}</p>
                  <p>{currentInvoice.userLocation}</p>
                </div>
                <div className="text-right">
                  <p><strong>Issue Date:</strong> {formatDate(currentInvoice.issueDate)}</p>
                  <p><strong>Due Date:</strong> {formatDate(currentInvoice.dueDate)}</p>
                  <p><strong>Amount:</strong> KSH {currentInvoice.amount.toLocaleString()}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SMS Templates */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6">SMS Templates</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button
            onClick={() => handleGenerateSMS('invoice')}
            className="p-6 bg-blue-50 rounded-xl border-2 border-blue-200 hover:border-blue-400 transition-all duration-200 hover:shadow-lg"
          >
            <MessageSquare className="w-8 h-8 text-blue-600 mb-2" />
            <div className="font-semibold text-blue-800">Invoice SMS</div>
            <div className="text-sm text-blue-600">Send invoice notification</div>
          </button>
          
          <button
            onClick={() => handleGenerateSMS('reminder')}
            className="p-6 bg-yellow-50 rounded-xl border-2 border-yellow-200 hover:border-yellow-400 transition-all duration-200 hover:shadow-lg"
          >
            <MessageSquare className="w-8 h-8 text-yellow-600 mb-2" />
            <div className="font-semibold text-yellow-800">Reminder SMS</div>
            <div className="text-sm text-yellow-600">Send payment reminder</div>
          </button>
          
          <button
            onClick={() => handleGenerateSMS('confirmation')}
            className="p-6 bg-green-50 rounded-xl border-2 border-green-200 hover:border-green-400 transition-all duration-200 hover:shadow-lg"
          >
            <MessageSquare className="w-8 h-8 text-green-600 mb-2" />
            <div className="font-semibold text-green-800">Payment Confirmation</div>
            <div className="text-sm text-green-600">Confirm payment received</div>
          </button>
        </div>

        {/* SMS Preview */}
        {showSMSPreview && (
          <div className="mt-6 p-6 bg-gray-50 rounded-xl">
            <h5 className="font-semibold text-gray-800 mb-4">SMS Preview</h5>
            <div className="bg-white p-4 rounded-lg border font-mono text-sm whitespace-pre-wrap">
              {currentSMS}
            </div>
            <button
              onClick={handleCopySMS}
              className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition flex items-center"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy to Clipboard
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default InvoiceGenerator;