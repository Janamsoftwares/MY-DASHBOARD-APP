import React from 'react';
import { Section } from '../types';
import { 
  BarChart3, 
  UserPlus, 
  Users, 
  RefreshCw, 
  FileText, 
  Globe, 
  LogOut,
  Activity
} from 'lucide-react';

interface SidebarProps {
  currentSection: Section;
  onNavigate: (section: Section) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentSection, onNavigate, onLogout }) => {
  const navItems = [
    { id: 'dashboard' as Section, label: 'Dashboard', icon: BarChart3 },
    { id: 'register-user' as Section, label: 'Register User', icon: UserPlus },
    { id: 'manage-users' as Section, label: 'Manage Users', icon: Users },
    { id: 'renewals' as Section, label: 'Renewals', icon: RefreshCw },
    { id: 'invoice-generator' as Section, label: 'Invoice Generator', icon: FileText },
    { id: 'website-bookings' as Section, label: 'Website Bookings', icon: Globe },
  ];

  return (
    <aside className="w-72 h-screen bg-gradient-to-b from-indigo-900 via-purple-900 to-gray-900 shadow-2xl flex flex-col text-white relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -translate-y-16 translate-x-16"></div>
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white opacity-5 rounded-full translate-y-12 -translate-x-12"></div>
      
      {/* Header */}
      <div className="p-6 border-b border-white/20 backdrop-blur-sm bg-white/10">
        <h2 className="text-3xl font-extrabold tracking-wide mb-2">Dr.Net Admin</h2>
        <p className="text-sm text-gray-200 mt-1 flex items-center">
          <Activity className="w-3 h-3 mr-2 text-green-400 animate-pulse" />
          Julius - CTO
        </p>
      </div>
      
      {/* Navigation */}
      <nav className="p-4 space-y-3 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentSection === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full text-left py-4 px-6 rounded-xl transition-all duration-300 backdrop-blur-sm border border-white/10 hover:scale-105 hover:shadow-lg ${
                isActive 
                  ? 'bg-white/20 shadow-lg transform scale-105' 
                  : 'hover:bg-white/20'
              }`}
            >
              <div className="flex items-center">
                <Icon className="w-6 h-6 mr-4" />
                <span className="font-medium text-lg">{item.label}</span>
              </div>
            </button>
          );
        })}
      </nav>
      
      {/* Logout */}
      <div className="p-4 border-t border-white/20">
        <button
          onClick={onLogout}
          className="w-full bg-gradient-to-r from-red-500 to-pink-600 text-white px-6 py-3 rounded-xl hover:from-red-600 hover:to-pink-700 transition-all duration-300 font-semibold shadow-lg hover:scale-105"
        >
          <div className="flex items-center justify-center">
            <LogOut className="w-5 h-5 mr-2" />
            Log Out
          </div>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;