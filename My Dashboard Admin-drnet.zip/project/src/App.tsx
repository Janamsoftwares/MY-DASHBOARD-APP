import React, { useState, useEffect } from 'react';
import { User, Booking, Section } from './types';
import { sampleUsers, sampleBookings } from './data/sampleData';
import { useLocalStorage } from './hooks/useLocalStorage';
import { authService } from './services/authService';
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import RegisterUser from './components/RegisterUser';
import ManageUsers from './components/ManageUsers';
import Renewals from './components/Renewals';
import InvoiceGenerator from './components/InvoiceGenerator';
import WebsiteBookings from './components/WebsiteBookings';
import DetailedView from './components/DetailedView';
import Swal from 'sweetalert2';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [users, setUsers] = useLocalStorage<User[]>('drnet-users', sampleUsers);
  const [bookings, setBookings] = useLocalStorage<Booking[]>('drnet-bookings', sampleBookings);
  const [currentSection, setCurrentSection] = useState<Section>('dashboard');
  const [detailedView, setDetailedView] = useState<{
    isVisible: boolean;
    title: string;
    users: User[];
  }>({
    isVisible: false,
    title: '',
    users: []
  });

  // Check authentication status on app load
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const isValid = await authService.verifyToken();
        setIsAuthenticated(isValid);
      } catch (error) {
        console.error('Auth check failed:', error);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Auto-logout on token expiration
  useEffect(() => {
    if (isAuthenticated) {
      const checkTokenExpiry = () => {
        if (!authService.isAuthenticated()) {
          handleLogout(true); // Silent logout
        }
      };

      // Check every minute
      const interval = setInterval(checkTokenExpiry, 60000);
      return () => clearInterval(interval);
    }
  }, [isAuthenticated]);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleUserRegistered = (newUser: User) => {
    setUsers(prev => [...prev, newUser]);
  };

  const handleDeleteUser = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user._id === userId ? { ...user, isDeleted: true } : user
    ));
  };

  const handleUserUpdated = (updatedUser: User) => {
    setUsers(prev => prev.map(user => 
      user._id === updatedUser._id ? updatedUser : user
    ));
  };

  const handleShowDetailedView = (type: string) => {
    const now = new Date();
    let filteredUsers: User[] = [];
    let title = '';

    switch (type) {
      case 'users':
        filteredUsers = users.filter(u => !u.isDeleted);
        title = 'All Users';
        break;
      case 'active':
        filteredUsers = users.filter(u => !u.isDeleted && new Date(u.expiryDate) > now);
        title = 'Active Users';
        break;
      case 'expired':
        filteredUsers = users.filter(u => !u.isDeleted && new Date(u.expiryDate) <= now);
        title = 'Expired Users';
        break;
      default:
        return;
    }

    setDetailedView({
      isVisible: true,
      title,
      users: filteredUsers
    });
  };

  const handleCloseDetailedView = () => {
    setDetailedView({
      isVisible: false,
      title: '',
      users: []
    });
  };

  const handleRefreshBookings = () => {
    // In a real app, this would fetch from an API
    setBookings([...bookings]);
  };

  const handleLogout = async (silent = false) => {
    if (!silent) {
      const result = await Swal.fire({
        title: 'Logout?',
        text: 'Are you sure you want to logout?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, logout',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        background: '#ffffff',
        customClass: {
          popup: 'rounded-2xl'
        }
      });

      if (!result.isConfirmed) {
        return;
      }
    }

    try {
      await authService.logout();
      setIsAuthenticated(false);
      setCurrentSection('dashboard');
      setDetailedView({
        isVisible: false,
        title: '',
        users: []
      });

      if (!silent) {
        await Swal.fire({
          title: 'Goodbye!',
          text: 'You have been logged out successfully.',
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
          background: '#ffffff',
          customClass: {
            popup: 'rounded-2xl'
          }
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
      // Force logout even if API call fails
      setIsAuthenticated(false);
    }
  };

  const renderCurrentSection = () => {
    switch (currentSection) {
      case 'dashboard':
        return (
          <>
            <Dashboard 
              users={users} 
              bookings={bookings} 
              onShowDetailedView={handleShowDetailedView} 
            />
            <DetailedView
              isVisible={detailedView.isVisible}
              title={detailedView.title}
              users={detailedView.users}
              onClose={handleCloseDetailedView}
            />
          </>
        );
      case 'register-user':
        return <RegisterUser onUserRegistered={handleUserRegistered} />;
      case 'manage-users':
        return <ManageUsers users={users} onDeleteUser={handleDeleteUser} />;
      case 'renewals':
        return <Renewals users={users} onUserUpdated={handleUserUpdated} />;
      case 'invoice-generator':
        return <InvoiceGenerator users={users} />;
      case 'website-bookings':
        return <WebsiteBookings bookings={bookings} onRefreshBookings={handleRefreshBookings} />;
      default:
        return null;
    }
  };

  // Show loading screen while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-100 via-blue-50 to-indigo-100">
        <div className="text-center">
          <div className="loading-spinner mx-auto mb-4 w-12 h-12"></div>
          <p className="text-gray-600 font-medium">Loading Dr.Net Admin Portal...</p>
        </div>
      </div>
    );
  }

  // Show login screen if not authenticated
  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-purple-100 via-blue-50 to-indigo-100">
      <Sidebar 
        currentSection={currentSection}
        onNavigate={setCurrentSection}
        onLogout={() => handleLogout(false)}
      />
      
      <main className="flex-1 p-8 overflow-y-auto">
        {renderCurrentSection()}
      </main>
    </div>
  );
}

export default App;