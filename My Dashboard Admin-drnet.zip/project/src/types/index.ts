export interface User {
  _id: string;
  name: string;
  phone: string;
  location: string;
  subscriptionAmount: number;
  routerCost: number;
  expiryDate: string;
  paidSubscription: boolean;
  paymentDate: string;
  package: string;
  isDeleted?: boolean;
}

export interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  package: string;
  message: string;
  date: string;
}

export interface Invoice {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  userLocation: string;
  amount: number;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  status: string;
}

export type Section = 'dashboard' | 'register-user' | 'manage-users' | 'renewals' | 'invoice-generator' | 'website-bookings';