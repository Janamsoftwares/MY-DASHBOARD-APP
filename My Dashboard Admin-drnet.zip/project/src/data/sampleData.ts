import { User, Booking } from '../types';

export const sampleUsers: User[] = [
  {
    _id: '1',
    name: 'John Doe',
    phone: '+254700123456',
    location: 'Nairobi',
    subscriptionAmount: 2500,
    routerCost: 5000,
    expiryDate: '2025-07-15',
    paidSubscription: true,
    paymentDate: '2025-06-15',
    package: 'Gold Plan - Up to 15 Mbps (Ksh 2,500/Month)'
  },
  {
    _id: '2',
    name: 'Jane Smith',
    phone: '+254711234567',
    location: 'Mombasa',
    subscriptionAmount: 3000,
    routerCost: 0,
    expiryDate: '2025-07-30',
    paidSubscription: true,
    paymentDate: '2025-06-30',
    package: 'Platinum Plan - Up to 20 Mbps (Ksh 3,000/Month)'
  },
  {
    _id: '3',
    name: 'Peter Kamau',
    phone: '+254722345678',
    location: 'Kisumu',
    subscriptionAmount: 2000,
    routerCost: 3500,
    expiryDate: '2025-07-10',
    paidSubscription: false,
    paymentDate: '2025-06-10',
    package: 'Silver Plan - Up to 10 Mbps (Ksh 2,000/Month)'
  }
];

export const sampleBookings: Booking[] = [
  {
    id: '1',
    name: 'Alice Johnson',
    email: 'alice@email.com',
    phone: '+254733456789',
    location: 'Karen',
    package: 'Super Plan',
    message: 'Interested in high-speed internet for home office',
    date: '2025-07-01'
  }
];