import dayjs from 'dayjs';

export const formatDate = (dateString: string): string => {
  return dayjs(dateString).format('MMM D, YYYY');
};

export const formatCurrency = (amount: number): string => {
  return `Ksh ${amount.toLocaleString()}`;
};

export const generateInvoiceNumber = (): string => {
  return 'INV-' + Math.random().toString(36).substr(2, 9).toUpperCase();
};

export const exportToCSV = (data: any[], filename: string) => {
  const headers = ['Name', 'Phone', 'Location', 'Package', 'Subscription Amount', 'Router Cost', 'Payment Date', 'Expiry Date', 'Status'];
  
  const csvContent = [
    headers.join(','),
    ...data.map(user => [
      `"${user.name}"`,
      `"${user.phone}"`,
      `"${user.location}"`,
      `"${user.package}"`,
      `"${user.subscriptionAmount}"`,
      `"${user.routerCost || 0}"`,
      `"${user.paymentDate}"`,
      `"${user.expiryDate}"`,
      `"${user.paidSubscription ? 'Paid' : 'Unpaid'}"`
    ].join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};