import jsPDF from 'jspdf';
import { Invoice } from '../types';
import { formatDate } from './formatters';

export const generateInvoicePDF = (invoice: Invoice): void => {
  const pdf = new jsPDF();
  
  // Company branding
  pdf.setFontSize(24);
  pdf.setFont('helvetica', 'bold');
  pdf.setTextColor(220, 38, 127);
  pdf.text('DR.NET TECHNOLOGY LABS', 20, 30);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.setTextColor(100, 100, 100);
  pdf.text('Internet Service Provider & Technology Solutions', 20, 38);
  pdf.text('Phone: 0701782354 | Email: dr.netinnovations@gmail.com', 20, 45);
  pdf.text('Website: www.drnet.co.ke', 20, 52);
  
  // Invoice header
  pdf.setFontSize(20);
  pdf.setFont('helvetica', 'bold');
  pdf.setTextColor(0, 0, 0);
  pdf.text('INVOICE', 150, 30);
  
  // Invoice details box
  pdf.setDrawColor(220, 38, 127);
  pdf.setLineWidth(0.5);
  pdf.rect(120, 35, 70, 25);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Invoice #: ${invoice.invoiceNumber}`, 125, 42);
  pdf.text(`Issue Date: ${formatDate(invoice.issueDate)}`, 125, 48);
  pdf.text(`Due Date: ${formatDate(invoice.dueDate)}`, 125, 54);
  
  // Client information
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('BILL TO:', 20, 80);
  
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text(invoice.userName, 20, 90);
  pdf.text(`Phone: ${invoice.userPhone}`, 20, 98);
  pdf.text(`Location: ${invoice.userLocation}`, 20, 106);
  
  // Service details table
  const startY = 130;
  
  // Table header
  pdf.setFillColor(240, 240, 240);
  pdf.rect(20, startY, 170, 10, 'F');
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'bold');
  pdf.text('DESCRIPTION', 25, startY + 7);
  pdf.text('PERIOD', 100, startY + 7);
  pdf.text('AMOUNT (KSH)', 140, startY + 7);
  
  // Table content
  pdf.setFont('helvetica', 'normal');
  const contentY = startY + 20;
  pdf.text('Internet Subscription Service', 25, contentY);
  pdf.text('Monthly Service', 100, contentY);
  pdf.text(invoice.amount.toLocaleString(), 145, contentY);
  
  // Subtotal and total
  const totalY = contentY + 30;
  pdf.setDrawColor(0, 0, 0);
  pdf.line(120, totalY - 5, 190, totalY - 5);
  
  pdf.setFont('helvetica', 'bold');
  pdf.text('SUBTOTAL:', 120, totalY);
  pdf.text(`KSH ${invoice.amount.toLocaleString()}`, 160, totalY);
  
  pdf.text('TOTAL DUE:', 120, totalY + 10);
  pdf.setFontSize(12);
  pdf.setTextColor(220, 38, 127);
  pdf.text(`KSH ${invoice.amount.toLocaleString()}`, 160, totalY + 10);
  
  // Payment instructions with M-PESA details
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.setTextColor(0, 0, 0);
  pdf.text('PAYMENT INSTRUCTIONS:', 20, totalY + 30);
  pdf.text('• M-PESA: Lipa na M-Pesa Buy Goods', 20, totalY + 38);
  pdf.text('• Till Number: 5626320', 20, totalY + 45);
  pdf.text('• Name: DR.NET TECHNOLOGY LABS', 20, totalY + 52);
  pdf.text(`• Reference: ${invoice.invoiceNumber}`, 20, totalY + 59);
  pdf.text('• Payment due within 7 days of invoice date', 20, totalY + 66);
  pdf.text('• For assistance call: 0701782354', 20, totalY + 73);
  
  // Footer
  pdf.setFontSize(8);
  pdf.setTextColor(100, 100, 100);
  pdf.text('Thank you for choosing DR.NET TECHNOLOGY LABS for your internet needs!', 20, 270);
  pdf.text('For support or inquiries, contact us at dr.netinnovations@gmail.com or 0701782354', 20, 277);
  
  // Save the PDF
  pdf.save(`DR-NET-Invoice-${invoice.invoiceNumber}.pdf`);
};