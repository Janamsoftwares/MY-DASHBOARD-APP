import dayjs from 'dayjs';
import { Invoice } from '../types';

export const generateInvoiceMessage = (invoice: Invoice): string => {
  const dueDate = dayjs(invoice.dueDate).format('MMM D, YYYY');
  
  return `Dear ${invoice.userName},

Your DR.NET internet subscription has expired. 

Invoice #${invoice.invoiceNumber}
Amount Due: KSH ${invoice.amount.toLocaleString()}
Due Date: ${dueDate}

Please renew to continue enjoying our high-speed internet service.

Payment via M-PESA:
• Lipa na M-Pesa Buy Goods
• Till Number: 5626320
• Name: DR.NET TECHNOLOGY LABS
• Reference: ${invoice.invoiceNumber}

Contact us: 0701782354
DR.NET TECHNOLOGY LABS`;
};

export const generateReminderMessage = (invoice: Invoice): string => {
  const daysOverdue = Math.floor((Date.now() - new Date(invoice.dueDate).getTime()) / (1000 * 60 * 60 * 24));
  
  return `REMINDER: ${invoice.userName}

Your DR.NET subscription payment is ${daysOverdue} day(s) overdue.

Invoice #${invoice.invoiceNumber}
Amount: KSH ${invoice.amount.toLocaleString()}

Please pay immediately to avoid service suspension.

Pay via M-PESA:
• Lipa na M-Pesa Buy Goods
• Till Number: 5626320
• Reference: ${invoice.invoiceNumber}

DR.NET TECHNOLOGY LABS`;
};

export const generatePaymentConfirmation = (invoice: Invoice): string => {
  return `Payment Confirmed! 

Thank you ${invoice.userName}!

Invoice #${invoice.invoiceNumber} - PAID
Amount: KSH ${invoice.amount.toLocaleString()}

Your DR.NET internet service has been renewed for 30 days.

Questions? Call 0701782354
DR.NET TECHNOLOGY LABS`;
};